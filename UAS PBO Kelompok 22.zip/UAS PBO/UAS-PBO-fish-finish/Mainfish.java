import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Mainfish here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Mainfish extends Actor
{
    /**
     * Act - do whatever the Mainfish wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        checkKeyPress();
        checkCollision();
    }
    private void checkKeyPress(){
        if(Greenfoot.isKeyDown("up")){
            setLocation(getX(),getY()-6);
        }
        if(Greenfoot.isKeyDown("down")){
            setLocation(getX(),getY()+6);
        }
        if(Greenfoot.isKeyDown("left")){
            setLocation(getX()-4,getY());
        }
        if(Greenfoot.isKeyDown("right")){
            setLocation(getX()+4,getY());
        }
    }
    private void checkCollision(){
        if(isTouching(Fish1.class)){
            removeTouching(Fish1.class);
            MyWorld.score.increase(2);
            Level2.score.increase(3);
            Level3.score.increase(4);
            Greenfoot.playSound("bite1.wav");
        }
        if(isTouching(Fish2.class)){
            removeTouching(Fish2.class);
            MyWorld.score.increase(4);
            Level2.score.increase(5);
            Level3.score.increase(6);
            Greenfoot.playSound("bite1.wav");
        }
        if(isTouching(Fish3.class)){
            removeTouching(Fish2.class);
            Level2.score.increase(6);
            Level3.score.increase(7);
            Greenfoot.playSound("bite1.wav");
        }
    }
}
