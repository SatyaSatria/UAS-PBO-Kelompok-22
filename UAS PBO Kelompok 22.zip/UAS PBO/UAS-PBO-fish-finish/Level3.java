import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level3 extends World
{
    static Counter score = new Counter("Score : ");
    static Counter hp = new Counter("Hp : ");
    /**
     * Constructor for objects of class Level3.
     * 
     */
    public Level3()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(950, 550, 1); 
        prepare();
    }
    public void act()
    {
        if(Greenfoot.getRandomNumber(160)< 3){
            addObject(new Fish1(), 948, Greenfoot.getRandomNumber(240));
        }
        if(Greenfoot.getRandomNumber(150)< 3){
            addObject(new Fish2(), 948, Greenfoot.getRandomNumber(3600));
        }
        if(Greenfoot.getRandomNumber(100)< 3){
            addObject(new Fish3(), 948, Greenfoot.getRandomNumber(400));
        }
        if(Greenfoot.getRandomNumber(500)< 3){
            addObject(new Predator1(), 948, Greenfoot.getRandomNumber(360));
        }
        if(Greenfoot.getRandomNumber(450)< 3){
            addObject(new Predator2(), 948, Greenfoot.getRandomNumber(500));
        }
        if(Greenfoot.getRandomNumber(600)< 3){
            addObject(new Predator3(), 948, Greenfoot.getRandomNumber(140));
        }
        if(Level3.score.getValue()>=200)
        {
            Greenfoot.delay(4);
            Greenfoot.setWorld(new WinPage());
        }
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Mainfish mainfish = new Mainfish();
        addObject(mainfish,32,271);
        Fish1 fish1 = new Fish1();
        addObject(fish1,635,76);
        Fish1 fish12 = new Fish1();
        addObject(fish12,605,446);
        Fish2 fish2 = new Fish2();
        addObject(fish2,429,167);
        Fish2 fish22 = new Fish2();
        addObject(fish22,735,346);
        Fish3 fish3 = new Fish3();
        addObject(fish3,768,102);
        Fish3 fish32 = new Fish3();
        addObject(fish32,553,524);
        Predator2 predator2 = new Predator2();
        addObject(predator2,626,229);
        Predator1 predator1 = new Predator1();
        addObject(predator1,735,494);
        Predator3 predator3 = new Predator3();
        addObject(predator3,563,400);
        predator3.setLocation(709,356);
        Fish3 fish33 = new Fish3();
        addObject(fish33,212,54);
        predator2.setLocation(433,48);
        
        addObject(score,80,45);
        score.setValue(0);
        addObject(hp, 870, 45);
        hp.setValue(0);
        Greenfoot.playSound("waterAmb1.wav");
    }
}
