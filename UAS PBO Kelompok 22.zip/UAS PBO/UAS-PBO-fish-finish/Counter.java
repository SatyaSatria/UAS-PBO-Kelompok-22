import greenfoot.*;

public class Counter extends Actor {
    private int value = 0;

    public Counter() {
        this("");
    }

    public Counter(String text) {
        updateImage(text);
    }

    public void setValue(int newValue) {
        value = newValue;
        updateImage("Score: " + value);
    }

    public int getValue() {
        return value;
    }

    public void increase(int amount) {
        value += amount;
        updateImage("Score: " + value);
    }

    private void updateImage(String text) {
        setImage(new GreenfootImage(text, 24, Color.WHITE, Color.BLACK));
    }
}
