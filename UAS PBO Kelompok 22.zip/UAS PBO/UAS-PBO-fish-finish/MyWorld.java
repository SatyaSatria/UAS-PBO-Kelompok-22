import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    static Counter score = new Counter("Score : ");
    static Counter hp = new Counter("Hp : ");
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {   
        super(950, 550, 1); 
        prepare();
    }
    
    public void act()
    {
        if(Greenfoot.getRandomNumber(90) < 3){
            addObject(new Fish1(),948, Greenfoot.getRandomNumber(360));
        }
        if(Greenfoot.getRandomNumber(150) < 3){
            addObject(new Fish2(),948, Greenfoot.getRandomNumber(360));
        }
        if(Greenfoot.getRandomNumber(200) < 3){
            addObject(new Predator1(),948, Greenfoot.getRandomNumber(360));
        }
        if(MyWorld.score.getValue()>=50)
        {
            Greenfoot.delay(4);
            Greenfoot.setWorld(new Level2());
        }
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Mainfish mainfish = new Mainfish();
        addObject(mainfish,92,301);
        mainfish.setLocation(56,274);
        Fish1 fish1 = new Fish1();
        addObject(fish1,643,58);
        Fish1 fish12 = new Fish1();
        addObject(fish12,445,148);
        Fish1 fish13 = new Fish1();
        addObject(fish13,801,274);
        Fish1 fish14 = new Fish1();
        addObject(fish14,776,463);
        Fish1 fish15 = new Fish1();
        addObject(fish15,616,304);
        Fish1 fish16 = new Fish1();
        addObject(fish16,764,151);
        fish16.setLocation(747,151);
        fish15.setLocation(624,310);
        fish15.setLocation(617,309);
        fish15.setLocation(596,329);
        removeObject(fish15);
        fish16.setLocation(767,139);
        removeObject(fish16);
        fish13.setLocation(787,272);
        fish13.setLocation(799,227);
        fish14.setLocation(743,492);
        fish12.setLocation(453,189);
        Fish2 fish2 = new Fish2();
        addObject(fish2,637,206);
        fish2.setLocation(784,119);
        Fish2 fish22 = new Fish2();
        addObject(fish22,395,72);
        Fish2 fish23 = new Fish2();
        addObject(fish23,517,358);
        Predator1 predator1 = new Predator1();
        addObject(predator1,512,24);
        predator1.setLocation(528,50);
        Predator1 predator12 = new Predator1();
        addObject(predator12,403,494);
        
        addObject(score,80,45);
        score.setValue(0);
        addObject(hp,870,45);
        hp.setValue(1);
        Greenfoot.playSound("waterAmb1.wav");
    }
}
